
const formulario = document.querySelector("form");
const getSenha = document.querySelector(".senha");
const getEmail = document.querySelector(".email");

function validarCampos() {


  // Email: formato correto
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(getEmail.value)) {
    alert("Digite um email válido.");
    return false;
  }

  // Senha: mínimo 6 caracteres
  if (getSenha.value.length < 6) {
    alert("A senha deve ter no mínimo 6 caracteres.");
    return false;
  }

  return true; // tudo OK ✅
}

async function login() {
    try {
        const resposta = await fetch("http://localhost:8080/Login", {
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
            },
            method: "POST",
            body: JSON.stringify({
                email: getEmail.value,
                senha: getSenha.value,
            }),
        });

        if (resposta.ok) {
            const usuario = await resposta.json();
            localStorage.setItem("usuario", JSON.stringify(usuario));
            window.location.href = "MenuUsuario.html";
        } else {
            alert("Usuário ou senha inválidos");
        }
    } catch (err) {
        console.error("Erro ao fazer login:", err);
        alert("Erro de conexão com o servidor.");
    }
}

async function consultarUsuarios() {
    try {
        // 1. Tenta carregar o usuário logado do localStorage
        const usuarioString = localStorage.getItem("usuario");

        if (!usuarioString) {
            alert("Você não está logado. Faça o login para consultar.");
            window.location.href = "Login.html";
            return;
        }

        const usuario = JSON.parse(usuarioString);

        const token = usuario.token;

        if (!token) {
            alert("Token não encontrado. Faça o login novamente.");
            return;
        }

        // 3. Envia a requisição GET com o token no cabeçalho
        const resposta = await fetch("http://localhost:8080/usuarios", {
            method: "GET",
            headers: {
                "Accept": "application/json",

                "Authorization": `Bearer ${token}`
            },
        });

        if (!resposta.ok) {

            if (resposta.status === 403) {
                alert("Erro: Você não tem permissão para ver esta lista.");
            } else {
                alert("Erro ao consultar usuários: " + resposta.status);
            }
            return;
        }

        const usuarios = await resposta.json();

        // Renderiza a lista
        listaUsuarios.innerHTML = `
      <table id="tabela" border="1" cellpadding="5">
        <tr><th>ID</th><th>Nome</th><th>Email</th><th>Telefone</th></tr>
        ${usuarios
            .map(
                (u) =>
                    `<tr>
                <td>${u.id}</td>
                <td>${u.nome}</td>
                <td>${u.email}</td>
                <td>${u.telefone ?? "-"}</td>
              </tr>`
            )
            .join("")}
      </table>`;
    } catch (err) {
        console.error("Erro ao consultar usuários:", err);
        alert("Erro ao conectar com o servidor.");
    }
}

function limpa(){
  getSenha.value = "";
  getEmail.value = "";
}

formulario.addEventListener('submit', function (event){
  event.preventDefault(); // Impede o envio padrão do formulário

  // 1. CHAMA A VALIDAÇÃO PRIMEIRO
  if (validarCampos()) {
    login(); // Envia os dados
    limpa();     // Limpa o formulário
  }
  
}); // envia os dados do login

btnConsultar.addEventListener("click", consultarUsuarios); // abre tabela com todos os usuarios