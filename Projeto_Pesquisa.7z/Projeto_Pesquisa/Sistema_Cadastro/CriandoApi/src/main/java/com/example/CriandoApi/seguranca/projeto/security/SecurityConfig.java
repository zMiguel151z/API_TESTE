package com.example.CriandoApi.seguranca.projeto.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;



@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // 1. Injete o filtro que você criou (SecurityFilter.java)
    @Autowired
    private SecurityFilter securityFilter;

    // 2. Define o Bean da cadeia de filtros de segurança
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        HttpSecurity httpSecurity = http
                // DESABILITA O CSRF: Correção principal para o erro 403 no POST do JavaScript
                .csrf(csrf -> csrf.disable())

                // Define a política de sessão como STATELESS (sem estado, pois usamos JWT)
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // Configura as regras de autorização para cada endpoint
                .authorizeHttpRequests(authorize -> authorize

                        // Permite acesso PÚBLICO ao endpoint de Login
                        .requestMatchers(HttpMethod.POST, "/Login").permitAll()

                        // Permite acesso PÚBLICO ao endpoint de CRIAR USUÁRIOS
                        // (Necessário para a sua tela de cadastro)
                        .requestMatchers(HttpMethod.POST, "/usuarios").permitAll()

                        // Exige autenticação para TODAS as outras requisições
                        .anyRequest().authenticated()
                )

                // Adiciona o seu filtro (SecurityFilter) para ser executado ANTES
                // do filtro padrão de autenticação do Spring.
                .addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // 3. Define o Bean do PasswordEncoder (BCrypt)
    //    Isso permite que você o injete em outros serviços (como o UsuarioService)
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // 4. Define o Bean do AuthenticationManager
    //    (Útil se você for usar o fluxo de autenticação padrão do Spring no futuro)
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}