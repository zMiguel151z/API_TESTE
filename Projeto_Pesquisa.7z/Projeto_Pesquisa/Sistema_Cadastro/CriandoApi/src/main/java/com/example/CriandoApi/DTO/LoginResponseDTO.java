package com.example.CriandoApi.DTO;

public record LoginResponseDTO( int id,
                                String nome,
                                String email,
                                String telefone,
                                String token) {
}
