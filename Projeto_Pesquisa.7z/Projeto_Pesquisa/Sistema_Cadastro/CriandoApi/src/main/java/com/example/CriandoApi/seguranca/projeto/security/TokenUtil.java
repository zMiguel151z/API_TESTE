package com.example.CriandoApi.seguranca.projeto.security;

import java.security.Key;
import java.util.Collections;
import java.util.Date;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import com.example.CriandoApi.Model.Usuario;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.HttpServletRequest;

public class TokenUtil {

	private static final String HEADER = "Authorization";
	private static final String PREFIX = "Bearer ";
	// ATENÇÃO: A expiração estava 1 * 60 * 60 * 1000, que é 1 hora, não 12h.
	// Para 12 horas, seria: 12 * 60 * 60 * 1000
	private static final long EXPIRATION = 12 * 60 * 60 * 1000; // 12h
	private static final String SECRET_KEY = "MyK3Yt0T0k3nP4r@S3CuRiTY@Sp3c14L";
	private static final String EMISSOR = "DevNice";

	private static Key getSigningKey() {

		return Keys.hmacShaKeyFor(SECRET_KEY.getBytes());
	}

	public static String createToken(Usuario usuario) {
		Key secretKey = getSigningKey();

		String token = Jwts.builder()
				.setSubject(usuario.getNome())
				.setIssuer(EMISSOR)
				.setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
				.signWith(secretKey)
				.compact();

		return PREFIX + token;
	}

	private static boolean isExpirationValid(Date expiration) {
		return expiration.after(new Date(System.currentTimeMillis()));
	}

	private static boolean isEmissorValid(String emissor) {
		return emissor.equals(EMISSOR);
	}

	private static boolean isSubjectValid(String username) {
		return username != null && !username.isEmpty();
	}

	public static Authentication validate(HttpServletRequest request) {
		String token = request.getHeader(HEADER);
		if (token == null || !token.startsWith(PREFIX)) {
			return null;
		}

		token = token.replace(PREFIX, "");

		try {
			Claims claims = Jwts.parser()
					.setSigningKey(getSigningKey()) // MUDANÇA: setSigningKey
					// .build() // MUDANÇA: removido
					.parseClaimsJws(token) // MUDANÇA: parseClaimsJws
					.getBody(); // MUDANÇA: getBody

			String username = claims.getSubject();
			String issuer = claims.getIssuer();
			Date expira = claims.getExpiration();

			if (isSubjectValid(username) && isEmissorValid(issuer) && isExpirationValid(expira)) {
				return new UsernamePasswordAuthenticationToken(username, null, Collections.emptyList());
			}
		} catch (Exception e) {
			// Token inválido (expirado, assinatura errada, etc.)
			return null;
		}

		return null;
	}
}