package com.example.CriandoApi.seguranca.projeto.service;

import java.util.List;
import java.util.Optional;

import com.example.CriandoApi.DAO.IUsuario;
import com.example.CriandoApi.DTO.LoginResponseDTO;
import com.example.CriandoApi.DTO.UsuarioLoginDTO;
import com.example.CriandoApi.Model.Usuario;
import jakarta.validation.Valid;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.CriandoApi.seguranca.projeto.security.Token;
import com.example.CriandoApi.seguranca.projeto.security.TokenUtil;


@Service
public class UsuarioService {

    private IUsuario repository;
    private PasswordEncoder passwordEncoder;

    public UsuarioService(IUsuario repository) {
        this.repository = repository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }


    public List<Usuario> listarUsuario() {
        return (List<Usuario>) repository.findAll();
    }

    /*public Usuario buscarPorId(Integer id) {
        Optional<Usuario> usuario = repository.findById(id);
        return usuario.orElse(null);
    }*/

    public Usuario criarUsuario(Usuario usuario) {
        String encoder = this.passwordEncoder.encode(usuario.getSenha());
        usuario.setSenha(encoder);
        return repository.save(usuario);
    }

    public Usuario editarUsuario(Integer id, Usuario novosDados) {
        return repository.findById(id).map(u -> {
            u.setNome(novosDados.getNome());
            u.setEmail(novosDados.getEmail());
            u.setTelefone(novosDados.getTelefone());

            if (novosDados.getSenha() != null && !novosDados.getSenha().isEmpty()) {
                String encoder = this.passwordEncoder.encode(novosDados.getSenha());
                u.setSenha(encoder);
            }

            return repository.save(u);
        }).orElse(null);
    }


    public Boolean excluirUsuario(Integer id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

    /*
    public Boolean validarSenha(Usuario usuario) {
        Optional<Usuario> optUser = repository.findByEmail(usuario.getEmail());

        if (optUser.isEmpty()) {
            return false; 
        }

        Usuario usuarioBanco = optUser.get();
        return passwordEncoder.matches(usuario.getSenha(), usuarioBanco.getSenha());

    
   public Boolean validarSenhaPorEmailESenha(String email, String senha) {
        Optional<Usuario> optUser = repository.findByEmail(email);
        if (optUser.isEmpty()) return false;
        return passwordEncoder.matches(senha, optUser.get().getSenha());
    }*/

    public Token gerarToken(@Valid Usuario usuario) {
        Usuario user = repository.findBynomeOrEmail(usuario.getNome(), usuario.getEmail());
        if (user != null) {
            Boolean valid = passwordEncoder.matches(usuario.getSenha(), user.getSenha());
            if (valid) {
                return new Token(TokenUtil.createToken(user));
            }
        }
        return null;
    }

    public LoginResponseDTO autenticarEGerarToken(@Valid UsuarioLoginDTO dadosLogin) {


        Optional<Usuario> optUser = repository.findByEmail(dadosLogin.email());

        // 2. Se o usuário existir no banco
        if (optUser.isPresent()) {
            Usuario user = optUser.get();

            // 3. Verifica se a senha enviada (dadosLogin.senha()) bate com a senha
            //    criptografada do banco (user.getSenha())
            boolean valid = passwordEncoder.matches(dadosLogin.senha(), user.getSenha());

            if (valid) {
                // 4. Se a senha for válida, gera o token
                String tokenString = TokenUtil.createToken(user);

                // 5. CRIA E RETORNA O DTO DE RESPOSTA COMPLETO
                //    É ISSO QUE VAI CORRIGIR OS 'undefined'
                return new LoginResponseDTO(
                        user.getId(),
                        user.getNome(),
                        user.getEmail(),
                        user.getTelefone(),
                        tokenString
                );
            }
        }

        // 6. Se o usuário não existir ou a senha estiver errada, retorna null
        return null;
    }
}
