package com.example.CriandoApi.DTO;

public record UsuarioLoginDTO(String email, String senha) {
}
