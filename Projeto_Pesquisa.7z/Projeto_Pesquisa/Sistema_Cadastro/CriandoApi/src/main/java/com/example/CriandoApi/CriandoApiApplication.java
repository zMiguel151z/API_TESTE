package com.example.CriandoApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CriandoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CriandoApiApplication.class, args);
	}

}
