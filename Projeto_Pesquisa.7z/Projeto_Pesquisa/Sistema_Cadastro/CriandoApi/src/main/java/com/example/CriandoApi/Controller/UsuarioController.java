package com.example.CriandoApi.Controller;

import com.example.CriandoApi.Model.Usuario;
import com.example.CriandoApi.seguranca.projeto.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/usuarios")
public class UsuarioController  {

    @Autowired
    private UsuarioService service;

    // LISTAR TODOS (Protegido)
    @GetMapping
    public List<Usuario> listarUsuarios() {
        return service.listarUsuario();
    }

    // CRIAR USUÁRIO (Público - definido no SecurityConfig)
    @PostMapping
    public Usuario criarUsuario(@RequestBody Usuario usuario) {
        // 2. Usa o service, que vai criptografar a senha
        return service.criarUsuario(usuario);
    }

    // EDITAR USUÁRIO (Protegido)
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> editarUsuario(@PathVariable Integer id, @RequestBody Usuario usuario) {
        Usuario usuarioEditado = service.editarUsuario(id, usuario);
        if (usuarioEditado != null) {
            return ResponseEntity.ok(usuarioEditado);
        }
        return ResponseEntity.notFound().build();
    }

    // EXCLUIR USUÁRIO (Protegido)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirUsuario(@PathVariable Integer id) {
        // 4. Usa o service para deleta
        if (service.excluirUsuario(id)) {
            return ResponseEntity.noContent().build(); // 204 No Content
        }
        return ResponseEntity.notFound().build(); // 404 Not Found
    }
}