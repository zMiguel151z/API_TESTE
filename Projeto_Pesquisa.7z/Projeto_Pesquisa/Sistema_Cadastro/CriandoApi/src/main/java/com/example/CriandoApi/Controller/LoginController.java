package com.example.CriandoApi.Controller;

import com.example.CriandoApi.DTO.LoginResponseDTO;
import com.example.CriandoApi.DTO.UsuarioLoginDTO;
import com.example.CriandoApi.Model.Usuario;
import com.example.CriandoApi.seguranca.projeto.security.Token;
import com.example.CriandoApi.seguranca.projeto.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/Login")
public class LoginController {

    @Autowired
    private UsuarioService usuarioService; // 1. Injete o Service, não o DAO

    @PostMapping
    public ResponseEntity<LoginResponseDTO> fazerLogin(@Valid @RequestBody UsuarioLoginDTO dadosLogin) {

        // 3. Chame um serviço que autentica e retorna o DTO de Resposta
        LoginResponseDTO resposta = usuarioService.autenticarEGerarToken(dadosLogin);

        if (resposta != null) {
            // 4. Retorna o DTO completo com dados do usuário + token
            return ResponseEntity.ok(resposta);
        }

        // 5. Se falhar, retorna 401
        return ResponseEntity.status(401).build();
    }
}
